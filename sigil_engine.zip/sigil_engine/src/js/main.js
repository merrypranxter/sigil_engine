// Sigil engine renderer and interaction loop

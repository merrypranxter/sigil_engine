// Letter-to-geometric-primitive mapping

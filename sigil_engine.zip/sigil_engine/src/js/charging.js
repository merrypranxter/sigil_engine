// Intensity phases and particle emission

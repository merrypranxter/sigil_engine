// Letter condensation and duplicate removal

// TODO: glyph.vert

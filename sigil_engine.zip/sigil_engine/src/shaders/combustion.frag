// TODO: combustion.frag

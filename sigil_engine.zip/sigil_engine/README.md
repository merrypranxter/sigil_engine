# sigil_engine

> statement of intent → glyph → combustion → void. chaos magick as generative design.

A chaos magick sigil generator following the Austin Osman Spare method. Enter a statement of intent; the engine removes vowels and duplicate consonants, maps remaining letters to geometric primitives, and combines them into a unified glyph. The sigil is then "charged" through visual gnosis: flame trails, particle bursts, and strobing intensity before release into the void.

## Live Controls

| Key | Action |
|-----|--------|
| `Space` | Charge sigil (hold for intensity) |
| `R` | Release sigil into void |
| `N` | New sigil from text input |
| `G` | Toggle gallery view |
| `S` | Save current sigil to gallery |
| `C` | Toggle combustion particles |

## Named Regimes

- **Spare Method** — Classic letter condensation and combination
- **Rose Cross** — Rosicrucian alphabet-to-shape mapping
- **Automatic Drawing** — Random glyph generation (paranoia method)
- **Word Method** — Combine word shapes directly
- **Mantra Mode** — Visual representation of spoken charging
- **Void Release** — Dissolve animation with expanding particles

## The Math

Sigil generation algorithm:
1. Write statement of intent (e.g., "I WILL MEET MY GOAL")
2. Remove vowels: "WLLLLTMYGL"
3. Remove duplicates: "WL TM YG"
4. Map each consonant to geometric primitive
5. Overlay primitives with rotation/scaling
6. Refine: smooth intersections, add decorative elements

Charging intensity function:
- Phase 1 (0–2s): Glyph brightens, begins pulsing
- Phase 2 (2–8s): Strobing increases, particle trails emerge
- Phase 3 (8–12s): Maximum intensity, flame combustion
- Phase 4 (12–15s): Release, glyph dissolves, particles expand

## Acknowledgments

Austin Osman Spare, Peter J. Carroll's *Liber Null & Psychonaut*, Phil Hine's *Condensed Chaos*.

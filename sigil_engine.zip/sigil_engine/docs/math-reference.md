# Math Reference: sigil_engine

> TODO: add mathematical foundations, equations, and reference values.

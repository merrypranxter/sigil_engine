# Visual Targets: sigil_engine

> TODO: describe desired visual output, color palettes, and animation behavior.
